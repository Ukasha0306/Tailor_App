class AppFonts {

  static const sfProDisplayBold  = 'SF-Pro-Display-Bold' ;
  static const sfProDisplayRegular = 'SF-Pro-Display-Regular' ;
  static const sfProDisplayLight = 'SF-Pro-Display-Light' ;
  static const sfProDisplayMedium = 'SF-Pro-Display-Medium' ;
}