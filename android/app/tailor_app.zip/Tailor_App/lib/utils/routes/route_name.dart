

class RouteName {

  static const String splashScreen = 'splash';
  static const String loginView = 'login_view';
  static const String signUpScreen = 'signUp_screen';
  static const String  forgotScreen = 'forgot_screen';

  // dashboard
  static const String dashBoardScreen = 'dashBoard_screen';

}